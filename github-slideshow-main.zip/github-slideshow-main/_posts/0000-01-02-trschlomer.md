----
layout: slide
title: "welcome to our second slide!"
----
"This is the wittiest quote ever uttered."
Use the left arrow to go back!
